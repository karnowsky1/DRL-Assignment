import "./formInput.css"

const FormInput = ({ label, onChange, ...inputProps}) => {
  return (
    <div className="formInput">
      <label>{label}</label>
      <input 
        {...inputProps}
        onChange={onChange}
        />  
    </div>
  )
}

export default FormInput