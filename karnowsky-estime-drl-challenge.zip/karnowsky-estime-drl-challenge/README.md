Data Model for Unter

Assumptions:
1. Driver "shifts" can start and stop multiple times throughout a given daily
2. Rides can have mupltiple Passengers
3. Payments are calculated based on time of day, milaege driven, length of ride and number of passengers
4. Name is not stated in the the requirements, names were excluded from the db to save space and keep anonymity
5. The average rating per driver will be calculated daily with each ride being weighed equally
6. The system will be more focused on being able to calculate metrics on a daily basis based on requirements

Considerations: 
1. The system will be designed to have only the necessary fields for a functional schema so that the system can scale efficiently
2. Drivers can have multiple passengers for a given ride, passengers may only have one driver for a given ride
3. Shifts were not specifically recorded as a table since the requirements want to evaluate metrics based on daily activity (for now)
4. Types were intention not discussed due to lack of information, could be added to schema on request 

---Drivers---
driver_id (PK)
today_average_rating
today_total_rides
today_total_tips
today_total_revenue

---Passengers---
passenger_id (PK)

---Rides---
ride_id (PK)
driver_id (FK to Drivers)
start_time
end_time
mileage
ride_length
number_of_passengers
base_fare
total_fare
tips
ride_date (for easier daily aggregation)

---Ride Passengers---
ride_id (FK to Rides)
passenger_id (FK to Passengers)
rating (1-5 stars)

2. Before new requirements were added, the passengers table was created to keep track of passenger id's so that there was a log of passenger history/activity. 
Most of the data was saved the within the rides and the drivers tables so that the schema could scale well for a requirement change like this. It was also due to the 
fact that the sytem needed the ability to assess the drivers based on appropriate perfomance metrics.

New Schema Considerations
1. Ratings are now bi-directional. Not only does ratings need to be added for passengers. Not necessary to say which subject gave the rating until future requirements are provied (driver to passenger, passenger to passenger, passenger to driver)
2. Did not ask for daily metrics for passengers, this has been kept as a consideration

---Drivers---
driver_id (PK)
today_average_rating
today_total_rides
today_total_tips
today_total_revenue

---Passengers---
passenger_id (PK)
average_rating
total_rides

---Rides---
ride_id (PK)
driver_id (FK to Drivers)
start_time
end_time
mileage
ride_length
number_of_passengers
base_fare
total_fare
tips
total_rating -> the average rating for a given driver if there are multiple passengers (20 rating / 4 passenger -> 5)
passenger_rating
ride_date (for easier daily aggregation)

---Ride Passengers---
ride_id (FK to Rides) 
passenger_id (FK to Passengers)
driver_rating