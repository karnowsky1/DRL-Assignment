import axios from 'axios';
import './App.css';
import { useState } from 'react';
import FormInput from './components/FormInput';
import AgeGroupSummary from './components/AgeGroupSummary';

function App() {
  const [formValues, setFormValues] = useState({
    fullName: "",
    dateOfBirth: "",
    happiness: 1,
    energy: 1,
    hopefulness: 1,
    sleep: 1
  })
  
  const [results, setResults] = useState(null);

  const inputs = [
    {
      id: 1,
      name: "fullName",
      type: "text",
      placeholder: "Sam Smith",
      label: "Enter your full name",
      required: true,
    },
    {
      id: 2,
      name: "dateOfBirth",
      type: "date",
      placeholder: "(mm/dd/yyyy)",
      label: "Enter your date of birth (mm/dd/yyyy)",
      required: true,
      max: new Date().toISOString().split('T')[0]
    },
    {
      id: 3,
      name: "happiness",
      type: "number",
      placeholder: 1,
      label: "On a scale from 1-5, how happy do you feel?",
      min: 1,
      max: 5,
      required: true,
    },
    {
      id: 4,
      name: "energy",
      type: "number",
      placeholder: 1,
      label: "On a scale from 1-5, how energetic do you feel?",
      min: 1,
      max: 5,
    },
    {
      id: 5,
      name: "hopefulness",
      type: "number",
      placeholder: 1,
      label: "On a scale from 1-5, how hopeful do you feel about the future?",
      min: 1,
      max: 5,
      required: true,
    },
    {
      id: 6,
      name: "sleep",
      type: "number",
      placeholder: 1,
      label: "How many hours did you sleep last night?",
      min: 1, 
      max: 12,
      required: true,
    },
  ]

  const handleSubmit = (event) => {
    event.preventDefault()
    axios.post('http://localhost:3001/submit', formValues)
      .then(response => {
        setResults(response.data)
      })
  }

  const onChange = (event) => {
    setFormValues({...formValues, [event.target.name]: event.target.value})
  }

  return (
    <div className="App">
      <form onSubmit={handleSubmit}>
        <h1>Health Survey</h1>
        {inputs.map((input) => (
          <FormInput 
            key={input.id} 
            {...input} 
            value={formValues[input.name]} 
            onChange={onChange}
          />
        ))}
        <button>Submit</button>
      </form>
      {results && (
        <>
          <div className="results">
            <h2>Results</h2>
            
            <p>Your happiness today: {formValues.happiness}, Average happiness: {results.userAverageHappiness}</p>
            <p>Average happiness of your age group: {results.ageGroupAverageHappiness}</p>
            <p>Your energy today: {formValues.energy}, Average energy: {results.userAverageEnergy}</p>
            <p>Average energy of your age group: {results.ageGroupAverageEnergy}</p>
            <p>Your hopefulness today: {formValues.hopefulness}, Average hopefulness: {results.userAverageHopefulness}</p>
            <p>Average hopefulness of your age group: {results.ageGroupAverageHopefulness}</p>
            <p>Your sleep hours today: {formValues.sleep}, Average sleep in hours: {results.userAverageSleep}</p>
            <p>Average sleep hours of your age group: {results.ageGroupAverageSleep}</p>
          </div>
          <div>
            <h2 className="results-header">Results Per Age Group</h2>
            <div className="outer-container">
              <div className="container">
                {results.ageGroupAverages.map((groupAverage) => (
                  <AgeGroupSummary key={groupAverage.ageGroup} {...groupAverage}/>
                ))}
              </div>
            </div>
          </div>
        </>
      )}
    </div>
  );
}

export default App;
