const AgeGroupSummary = ({ageGroup, avgHappiness, avgEnergy, avgHopefulness, avgSleep}) => {
  const ageFormatter = (age) => {
    if (age === "71-Infinity") {
      return "71+"
    } else {
      return age
    }
  }
  return (
    <div>
      <h4> Age Range: {ageFormatter(ageGroup)} yrs</h4>
      {avgHappiness ? (
        <>
          <p>Average happiness for people between {ageFormatter(ageGroup)} years old: {avgHappiness} </p>
          <p>Average energy for people between {ageFormatter(ageGroup)} years old: {avgEnergy} </p>
          <p>Average hopefulness for people between {ageFormatter(ageGroup)} years old: {avgHopefulness} </p>
          <p>Average sleep in hours for people between {ageFormatter(ageGroup)} years old: {avgSleep} </p>
        </>
        ) : (
          <p>No responses saved for users within this age range</p>
        )}
    </div>
  )
}

export default AgeGroupSummary