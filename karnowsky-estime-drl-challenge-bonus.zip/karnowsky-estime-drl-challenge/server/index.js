const cors = require('cors');
const express = require('express');
const path = require('path');
const sqlite3 = require('sqlite3').verbose();

const app = express();
const PORT = 3001;

// Middleware Setup
app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, 'public')));

const db = new sqlite3.Database('./questionnaire.db', (err) => {
  if (err) {
    console.error('Error opening database');
  } else {
    db.run(
      `
        CREATE TABLE IF NOT EXISTS responses (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          fullName TEXT,
          dateOfBirth TEXT,
          happiness INTEGER,
          energy INTEGER,
          hopefulness INTEGER,
          sleep INTEGER,
          date TEXT
        )
      `, (error) => {
          if(error) {
            console.error('Error creating table', error);
          }
        }
    );
  }
});

app.post('/submit', (request, response) => {
  const { fullName, dateOfBirth, happiness, energy, hopefulness, sleep } = request.body;
  const date = new Date().toISOString().split('T')[0];

  db.run(
    `
      INSERT INTO responses (fullName, dateOfBirth, happiness, energy, hopefulness, sleep, date)
      VALUES (?, ?, ?, ?, ?, ?, ?)
    `,
    [fullName, dateOfBirth, happiness, energy, hopefulness, sleep, date],
    function(error) {
      if (error) {
        response.status(500).send('Error submitting questionnaire response');
      } else {
        const userQuery = `SELECT * FROM responses WHERE fullName = ? AND dateOfBirth = ?;`;
        db.all(userQuery, [fullName, dateOfBirth], (error, userRows) => {
          if(error) {
            response.status(500).send('Error retrieving user results');
            return;
          }
          if(userRows.length === 0) {
            response.status(404).send('No responses found for user');
            return;
          }
          
          // Calculate user averages
          const userAveragesQuery = `
            SELECT
              AVG(happiness) as avgHappiness,
              AVG(energy) as avgEnergy,
              AVG(hopefulness) as avgHopefulness,
              AVG(sleep) as avgSleep
            FROM responses
            WHERE fullName = ? AND dateOfBirth = ?;
          `
          db.get(userAveragesQuery, [fullName, dateOfBirth], (error, userAverages) => {
            if(error) {
              response.status(500).send('Error calculating user averages');
              return;
            }
            const userAge = calculateAge(dateOfBirth);

            // Create promises for each age group query 
            const ageGroupAveragesPromises = ageGroups.map(group => {
              const ageGroupQuery = `
              SELECT
                AVG(happiness) as avgHappiness,
                AVG(energy) as avgEnergy,
                AVG(hopefulness) as avgHopefulness,
                AVG(sleep) as avgSleep
              FROM responses
              WHERE (julianday('now') - julianday(dateOfBirth)) / 365.25 BETWEEN ? AND ?;
            `;
              return new Promise((resolve, reject) => {
                db.get(ageGroupQuery, [group.min, group.max], (error, ageGroupAverages) => {
                  if(error) {
                    reject(error);
                  } else {
                    resolve({ group, averages: ageGroupAverages });
                  }
                });
              });
            });
            
            // Wait for all age group queries to complete
            Promise.all(ageGroupAveragesPromises).then(ageGroupAveragesResults => {
              const ageGroupAverages = ageGroupAveragesResults.map(result => ({
                ageGroup: `${result.group.min}-${result.group.max === Infinity ? 'infinity' : result.group.max}`,
                averages: result.averages
              }));
              
              const currentAgeGroup = ageGroupAverages.find(group => {
                const [min, max] = group.ageGroup.split('-').map(Number);
                return userAge >= min && (max === 'infinity' || userAge <= max);
              });

              const comparisonResults = {
                userAverageHappiness: userAverages.avgHappiness.toFixed(1),
                ageGroupAverageHappiness: currentAgeGroup.averages.avgHappiness.toFixed(1),
                userAverageEnergy: userAverages.avgEnergy.toFixed(1),
                ageGroupAverageEnergy: currentAgeGroup.averages.avgEnergy.toFixed(1),
                userAverageHopefulness: userAverages.avgHopefulness.toFixed(1),
                ageGroupAverageHopefulness: currentAgeGroup.averages.avgHopefulness.toFixed(1),
                userAverageSleep: userAverages.avgSleep.toFixed(1),
                ageGroupAverageSleep: currentAgeGroup.averages.avgSleep.toFixed(1),
                ageGroupAverages: ageGroupAverages.map((group) => ({
                  ageGroup: group.ageGroup,
                  avgHappiness: group.averages.avgHappiness? group.averages.avgHappiness.toFixed(1) : group.averages.avgHappiness,
                  avgEnergy: group.averages.avgEnergy ? group.averages.avgEnergy.toFixed(1) : group.averages.avgEnergy,
                  avgHopefulness: group.averages.avgHopefulness ? group.averages.avgHopefulness.toFixed(1) : group.averages.avgHopefulness,
                  avgSleep: group.averages.avgSleep ? group.averages.avgSleep.toFixed(1) :group.averages.avgSleep
                }))
              };
              response.status(200).send(comparisonResults);
            });
          });
        });
      }
    }
  );
});

const calculateAge = (dateOfBirth) => {
  const dob = new Date(dateOfBirth);
  const diff = Date.now() - dob.getTime();
  const ageDate = new Date(diff);
  return Math.abs(ageDate.getUTCFullYear() -1970);
};

const ageGroups = [
  { min: 0, max: 10 },
  { min: 11, max: 15 },
  { min: 16, max: 21 },
  { min: 22, max: 30 },
  { min: 31, max: 40 },
  { min: 41, max: 50 },
  { min: 51, max: 70 },
  { min: 71, max: Infinity }
];

app.listen(PORT, () => {console.log(`Server Port: ${PORT}`)});